cp ${BASEPATH} /usr/local/nsti -r
chmod 775 /usr/local/nsti -R
chown nagios:nagcmd /usr/local/nsti -R
