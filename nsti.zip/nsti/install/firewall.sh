iptables -I INPUT -p tcp --dport 80 -j ACCEPT
iptables-save
systemctl stop firewalld
systemctl disable firewalld
systemctl mask --now firewalld
echo 0 > /selinux/enforce
setenforce 0
