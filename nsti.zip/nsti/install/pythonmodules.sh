#!/bin/sh

pip install -r "${BASEPATH}/install/requirements.txt" --upgrade
