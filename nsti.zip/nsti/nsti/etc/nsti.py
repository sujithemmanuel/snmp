#~ Database Configuration Options
#~ Use mysql for MySQL and postgres for PostgreSQL
DB_TYPE='mysql'
DB_HOST='localhost'
DB_PORT='3306'
DB_NAME='snmptt'
DB_USER='snmpttuser'
DB_PASS='password'

#~ Page Display Options
TRUNCATE=100
PERPAGE=50
