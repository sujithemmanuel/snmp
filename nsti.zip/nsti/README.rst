Nagios SNMP Trap Interface (NSTI)
=================================

The Open Source Nagios SNMP Trap Interface is designed to be smart User Interface and organized database for all your SNMP needs.

Downloading NSTI
----------------

`Download from the Nagios Official Builds <http://assets.nagios.com/downloads/nsti/tarballs/>`_.

Developers should download the releases from Github.

We currently support this product for building on RHEL and CentOS
